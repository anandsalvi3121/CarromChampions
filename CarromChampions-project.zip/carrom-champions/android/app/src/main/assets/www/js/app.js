/* Carrom Champions — app shell: screens, HUD, face circles, voice, online protocol. */
(function () {
  'use strict';
  const { CarromGame, Sfx, consts } = window.Carrom;
  const { Room, Media } = window.CarromNet;
  const $ = s => document.querySelector(s), $$ = s => [...document.querySelectorAll(s)];

  // ---------- Settings ----------
  const store = {
    get(k, d) { try { const v = localStorage.getItem('cc_' + k); return v === null ? d : JSON.parse(v); } catch (e) { return d; } },
    set(k, v) { try { localStorage.setItem('cc_' + k, JSON.stringify(v)); } catch (e) { } },
  };
  const settings = { sound: store.get('sound', true), vibe: store.get('vibe', true), clock: store.get('clock', true) };
  Sfx.on = settings.sound;
  [['#set-sound', 'sound'], ['#set-vibe', 'vibe'], ['#set-turn-timer', 'clock']].forEach(([sel, k]) => {
    const el = $(sel); el.checked = settings[k];
    el.onchange = () => { settings[k] = el.checked; store.set(k, el.checked); Sfx.on = settings.sound; if (game) { game.o.vibrate = settings.vibe; if (k === 'clock') game.turnLimit = settings.clock ? 30000 : Infinity; } };
  });
  const nameIn = $('#in-name'); nameIn.value = store.get('name', '');
  nameIn.oninput = () => store.set('name', nameIn.value.trim());
  const myName = () => nameIn.value.trim() || 'Player';

  // ---------- Navigation ----------
  let current = 'scr-home';
  function go(id) { $$('.screen').forEach(s => s.classList.toggle('active', s.id === id)); current = id; if (id === 'scr-online') lobbyMedia(); }
  $$('[data-go]').forEach(b => b.onclick = () => go(b.dataset.go));
  function openModal(id) { $$('.modal').forEach(m => m.classList.remove('show')); $('#' + id).classList.add('show'); }
  function closeModals() { $$('.modal').forEach(m => m.classList.remove('show')); }
  $$('[data-modal]').forEach(b => b.onclick = () => openModal(b.dataset.modal));
  $$('[data-close]').forEach(b => b.onclick = () => { closeModals(); if (game && game.S.over) openModal('mdl-over'); });
  $$('.modal').forEach(m => m.addEventListener('click', e => { if (e.target === m && m.id !== 'mdl-over') closeModals(); }));
  function segValue(sel) { return +($(sel + ' button.on') || {}).dataset.v || 1; }
  $$('.seg').forEach(seg => seg.querySelectorAll('button').forEach(b => b.onclick = () => { seg.querySelectorAll('button').forEach(x => x.classList.toggle('on', x === b)); }));

  function toast(text, kind) {
    const t = document.createElement('div'); t.className = 'toast ' + (kind || ''); t.textContent = text;
    $('#toasts').appendChild(t); setTimeout(() => t.remove(), 2300);
  }

  // ---------- Media (face + voice) ----------
  function attachVideo(face, stream, muted) {
    const v = face.querySelector('video');
    if (!stream) { if (v.srcObject) v.srcObject = null; face.classList.remove('has-video'); return; }
    v.muted = !!muted;
    if (v.srcObject !== stream) v.srcObject = stream;
    const hasV = stream.getVideoTracks().some(t => t.enabled && t.readyState === 'live');
    face.classList.toggle('has-video', hasV);
    v.play().catch(() => { });
  }
  function setAvatar(face, name) { face.querySelector('.avatar').textContent = (name || '?').trim().charAt(0).toUpperCase() || '?'; }

  async function lobbyMedia(force) {
    const face = $('#lobby-face'), status = $('#cam-status'), btn = $('#btn-allow-media');
    setAvatar(face, myName());
    if (!force && !store.get('mediaAsked', false) && !Media.stream) { btn.style.display = ''; return; }
    btn.style.display = 'none'; status.textContent = 'Starting camera…';
    const s = await Media.start(); store.set('mediaAsked', true);
    if (s) { attachVideo(face, s, true); status.textContent = Media.hasVideo() ? 'Looking good! Your opponent will see this.' : 'Mic on — camera unavailable.'; }
    else { status.textContent = 'Camera & mic blocked. Allow them in Android Settings › Apps › Carrom Champions › Permissions.'; btn.style.display = ''; }
  }
  $('#btn-allow-media').onclick = () => lobbyMedia(true);

  // Voice activity glow
  const speakers = [];
  function watchSpeaking(stream, face) {
    try {
      if (!stream.getAudioTracks().length) return;
      Sfx.init(); const ctx = Sfx.ctx; if (!ctx) return;
      const src = ctx.createMediaStreamSource(stream), an = ctx.createAnalyser(); an.fftSize = 512; src.connect(an);
      speakers.push({ an, face, buf: new Uint8Array(an.fftSize), level: 0 });
    } catch (e) { }
  }
  function tickSpeaking() {
    for (const s of speakers) {
      s.an.getByteTimeDomainData(s.buf); let sum = 0; for (const v of s.buf) { const d = v - 128; sum += d * d; }
      const rms = Math.sqrt(sum / s.buf.length); s.level = s.level * .8 + rms * .2;
      s.face.classList.toggle('speaking', s.level > 4.5);
    }
  }

  // ---------- Game session ----------
  let game = null, room = null, session = null;
  const faceTop = $('#face-top'), faceBot = $('#face-bot');

  function bottomSeat() { if (!session) return 0; if (session.mode === 'online') return session.seat; if (session.mode === 'local') return game ? game.viewSeat() : 0; return 0; }
  function faceOf(seat) { return seat === bottomSeat() ? faceBot : faceTop; }
  function hudOf(seat) { return seat === bottomSeat() ? $('#hud-bot') : $('#hud-top'); }

  function startSession(opts) {
    session = opts; closeModals();
    go('scr-game');
    $('#hud-top').style.visibility = opts.mode === 'practice' ? 'hidden' : '';
    faceTop.style.display = opts.mode === 'practice' ? 'none' : '';
    $('#ctl-spk').classList.toggle('hidden', opts.mode !== 'online');
    $('#ctl-emoji').classList.toggle('hidden', opts.mode !== 'online');
    layout();
    if (game) game.destroy();
    game = new CarromGame({
      canvas: $('#board'), mode: opts.mode, localSeat: opts.seat || 0, matchTarget: opts.target, flipLocal: opts.flip,
      vibrate: settings.vibe,
      onPlace: x => net.place(x), onAim: a => net.aim(a), onShot: s => net.send({ t: 'shot', s }),
      onToast: toast,
      onTurn: () => refreshHud(),
      onResolved: (info, local) => {
        if (local && session.mode === 'online') net.send({ t: 'state', st: game.snapshot(), info });
        refreshHud();
        if (info.boardOver) setTimeout(() => showBoardOver(info), 900);
      },
    });
    game.turnLimit = settings.clock && opts.mode !== 'practice' ? (opts.clock === false ? Infinity : 30000) : Infinity;
    // Faces
    attachMediaToFaces();
    refreshHud();
    if (opts.mode === 'practice') toast('Practice — clear the board!', 'good');
    else if (opts.mode === 'online') toast(opts.seat === 0 ? 'You break · you play white' : `${opts.names[0]} breaks`, 'good');
    else toast(`${opts.names[0]} breaks`, 'good');
  }

  function attachMediaToFaces() {
    const m = session.mode, s = Media.stream;
    speakers.length = 0;
    if (m === 'online') {
      attachVideo(faceBot, s, true); setAvatar(faceBot, session.names[session.seat]);
      setAvatar(faceTop, session.names[1 - session.seat]);
      if (session.remoteStream) { attachVideo(faceTop, session.remoteStream, !spkOn); watchSpeaking(session.remoteStream, faceTop); faceTop.classList.toggle('has-video', session.remoteCam !== false && session.remoteStream.getVideoTracks().length > 0); }
      else attachVideo(faceTop, null);
      if (s) watchSpeaking(s, faceBot);
    } else {
      // One phone: the camera shows whoever is shooting.
      const turn = game ? game.S.turn : 0;
      for (const seat of [0, 1]) { const f = faceOf(seat); setAvatar(f, session.names[seat]); attachVideo(f, seat === turn ? s : null, true); }
    }
    syncControls();
  }

  function refreshHud() {
    if (!game || !session) return;
    const S = game.S, M = game.match;
    for (const seat of [0, 1]) {
      const h = hudOf(seat), col = S.colors[seat];
      h.querySelector('.chip').className = 'chip ' + col;
      h.querySelector('.nm').textContent = session.names[seat] + (session.mode === 'online' && seat === session.seat ? ' (you)' : '');
      const left = S.pieces.filter(p => p.k === col && p.on).length;
      let st = `Coins ${9 - left}/9`;
      if (S.queen.st === 'covered' && S.queen.by === seat) st += ' · 👑';
      h.querySelector('.st').textContent = session.mode === 'practice' ? `Shots ${S.shots} · ${19 - S.pieces.filter(p => p.k !== 's' && p.on).length}/19 pocketed` : st;
      h.querySelector('.pts b').textContent = session.mode === 'practice' ? S.shots : M.points[seat];
      h.querySelector('.pts .lbl').textContent = session.mode === 'practice' ? 'SHOTS' : (M.target > 1 ? `PTS /${M.target}` : 'PTS');
      h.classList.toggle('active', S.turn === seat && !S.over && session.mode !== 'practice');
      faceOf(seat).classList.toggle('turn', S.turn === seat);
    }
    const qb = $('#queen-badge');
    qb.classList.toggle('show', S.queen.st === 'pending');
    if (S.queen.st === 'pending') qb.textContent = `👑 ${session.names[S.queen.by]} must cover the Queen`;
    const mine = game.canControl();
    $('.slider-row').classList.toggle('off', !mine);
    const sl = $('#slider'); sl.min = consts.BASE_X0; sl.max = consts.BASE_X1;
    const flipped = game.viewSeat() === 1; sl.style.direction = flipped ? 'rtl' : 'ltr';
    sl.value = game.striker.x;
    $('#hint').textContent = S.over ? '' : mine ? 'Slide to position · touch striker & pull back to shoot'
      : session.mode === 'online' ? `${session.names[S.turn]} is playing…` : '';
    if (session.mode === 'local') attachMediaToFaces();
  }

  $('#slider').oninput = e => { if (game && game.canControl()) { game.setStrikerX(+e.target.value); net.place(game.striker.x); } };

  // Per-frame UI: turn clock rings, speaking glow, slider follow
  let lastTurnKey = '';
  (function uiLoop() {
    requestAnimationFrame(uiLoop);
    if (!game || current !== 'scr-game') return;
    tickSpeaking();
    const S = game.S, key = S.turn + '|' + game.phase + '|' + game.viewSeat();
    if (key !== lastTurnKey) { lastTurnKey = key; refreshHud(); }
    const prog = game.turnLimit === Infinity ? 0 : game.turnProgress();
    for (const seat of [0, 1]) {
      const c = faceOf(seat).querySelector('.ring circle');
      const on = seat === S.turn && game.phase === 'ready' && prog > 0;
      c.style.strokeDashoffset = on ? 295 * prog : 295;
      c.style.stroke = prog > .75 ? '#ff5a5a' : '#e7b84a';
    }
    if (game.drag && game.drag.type === 'place') $('#slider').value = game.striker.x;
    if (session.mode === 'online' && S.turn !== session.seat) $('#slider').value = game.striker.x;
  })();

  function showBoardOver(info) {
    if (!game || !game.S.over) return;
    const n = session.names, M = game.match;
    $('#over-score').innerHTML = session.mode === 'practice' ? '' : `<span>${esc(n[0])} <b>${M.points[0]}</b></span><span>${esc(n[1])} <b>${M.points[1]}</b></span>`;
    const next = $('#btn-next');
    if (session.mode === 'practice') {
      $('#over-title').textContent = 'Board cleared!'; $('#over-text').textContent = `You cleared all 19 pieces in ${game.S.shots} shots.`; next.textContent = 'Play again'; next.disabled = false;
    } else {
      const w = info.winner, done = M.done;
      $('#over-title').textContent = done ? `${n[w]} wins the match!` : `${n[w]} wins board ${M.boardNo}`;
      $('#over-text').textContent = info.boardPts != null ? `+${info.boardPts} points${info.queenBonus ? ' (incl. Queen +3)' : ''}` : '';
      next.textContent = done ? 'Rematch' : 'Next board';
      const canAdvance = session.mode !== 'online' || session.seat === 0;
      next.disabled = !canAdvance; if (!canAdvance) next.textContent = 'Waiting for host…';
    }
    openModal('mdl-over');
  }
  $('#btn-next').onclick = () => {
    if (!game) return;
    if (session.mode === 'practice' || game.match.done) game.restartMatch(); else game.nextBoard();
    closeModals(); refreshHud(); if (session.mode === 'local') attachMediaToFaces();
    if (session.mode === 'online') net.send({ t: 'state', st: game.snapshot(), info: null, newBoard: true });
    toast(`Board ${game.match.boardNo} — ${session.names[game.S.breaker]} breaks`, 'good');
  };
  $('#btn-leave2').onclick = () => leave();
  $('#btn-quit').onclick = () => leave();
  $('#ctl-menu').onclick = () => openModal('mdl-menu');

  function leave(msg) {
    closeModals();
    if (room) { room.destroy(); room = null; }
    if (game) { game.destroy(); game = null; }
    session = null; speakers.length = 0;
    [faceTop, faceBot].forEach(f => attachVideo(f, null));
    Media.stop();
    go('scr-home');
    if (msg) toast(msg, 'warn');
  }

  // ---------- Controls: mic / cam / speaker / emoji ----------
  let micOn = true, camOn = true, spkOn = true;
  function syncControls() {
    $('#ctl-mic').classList.toggle('off', !micOn || !Media.hasAudio());
    $('#ctl-cam').classList.toggle('off', !camOn || !Media.hasVideo());
    $('#ctl-spk').classList.toggle('off', !spkOn);
    faceBot.classList.toggle('muted', !micOn);
  }
  $('#ctl-mic').onclick = async () => {
    if (!Media.stream) { await Media.start(); if (session) attachMediaToFaces(); if (!Media.stream) return toast('Microphone permission is off', 'warn'); }
    micOn = !micOn; Media.setMic(micOn); net.send({ t: 'mic', on: micOn }); syncControls(); toast(micOn ? 'Mic on' : 'Mic muted');
  };
  $('#ctl-cam').onclick = async () => {
    if (!Media.stream) { await Media.start(); if (session) attachMediaToFaces(); if (!Media.hasVideo()) return toast('Camera permission is off', 'warn'); return; }
    camOn = !camOn; Media.setCam(camOn); net.send({ t: 'cam', on: camOn });
    const f = session && session.mode === 'online' ? faceBot : faceOf(game ? game.S.turn : 0);
    f.classList.toggle('has-video', camOn && Media.hasVideo()); syncControls();
  };
  $('#ctl-spk').onclick = () => { spkOn = !spkOn; faceTop.querySelector('video').muted = !spkOn; syncControls(); toast(spkOn ? 'Speaker on' : 'Opponent muted'); };
  $('#ctl-emoji').onclick = () => $('#emoji-pop').classList.toggle('show');
  $$('#emoji-pop button').forEach(b => b.onclick = () => { $('#emoji-pop').classList.remove('show'); floatEmoji(faceBot, b.textContent); net.send({ t: 'emoji', e: b.textContent }); });
  function floatEmoji(face, e) {
    const wrap = $('#board-wrap'), el = document.createElement('div'); el.className = 'float-emoji'; el.textContent = e;
    el.style.left = '50%'; el.style[face === faceTop ? 'top' : 'bottom'] = face === faceTop ? '30px' : '30px';
    wrap.appendChild(el); setTimeout(() => el.remove(), 1700);
  }

  // ---------- Online protocol ----------
  const net = {
    lastPlace: 0, lastAim: 0, aimTimer: null,
    send(m) { if (room && session && session.mode === 'online') room.send(m); },
    place(x) { const n = performance.now(); if (n - this.lastPlace > 45) { this.lastPlace = n; this.send({ t: 'place', x: Math.round(x * 10) / 10 }); } },
    aim(a) {
      const n = performance.now(); clearTimeout(this.aimTimer);
      const pack = a && { dx: +a.dx.toFixed(3), dy: +a.dy.toFixed(3), p: +a.p.toFixed(3) };
      if (!a || n - this.lastAim > 60) { this.lastAim = n; this.send({ t: 'aim', a: pack }); }
      else this.aimTimer = setTimeout(() => this.send({ t: 'aim', a: pack }), 70);
    },
  };

  function onMessage(m) {
    if (!m || typeof m !== 'object') return;
    switch (m.t) {
      case 'hello': // host receives
        if (!room || !room.isHost || session) return;
        pending.oppName = String(m.name || 'Player').slice(0, 14);
        room.send({ t: 'start', name: myName(), target: pending.target, clock: settings.clock });
        startSession({ mode: 'online', seat: 0, names: [myName(), pending.oppName], target: pending.target, remoteStream: pending.remoteStream, clock: settings.clock });
        break;
      case 'start': // joiner receives
        if (!room || room.isHost || session) return;
        startSession({ mode: 'online', seat: 1, names: [String(m.name || 'Host').slice(0, 14), myName()], target: m.target === 25 ? 25 : 1, remoteStream: pending.remoteStream, clock: m.clock !== false && settings.clock });
        break;
      case 'place': if (game && game.S.turn !== session.seat && typeof m.x === 'number') game.setStrikerX(m.x); break;
      case 'aim': if (game) game.remoteAim = m.a && isFinite(m.a.dx) ? m.a : null; break;
      case 'shot': if (game && game.S.turn !== session.seat && m.s) game.applyRemoteShot(m.s); break;
      case 'state':
        if (!game || !m.st) return;
        if (m.newBoard) closeModals();
        game.applyState(m.st, m.info || null); refreshHud();
        if (m.newBoard) toast(`Board ${game.match.boardNo} — ${session.names[game.S.breaker]} breaks`, 'good');
        break;
      case 'emoji': floatEmoji(faceTop, String(m.e || '').slice(0, 4)); break;
      case 'cam': session && (session.remoteCam = !!m.on); faceTop.classList.toggle('has-video', !!m.on && !!session.remoteStream); break;
      case 'mic': faceTop.classList.toggle('muted', !m.on); break;
    }
  }

  let pending = {};
  function newRoom() {
    if (room) room.destroy();
    pending = { remoteStream: null };
    room = new Room({
      onConnected: () => { if (!room.isHost) room.send({ t: 'hello', name: myName() }); else $('#wait-note').textContent = 'Opponent found! Starting…'; },
      onMessage,
      onRemoteStream: s => {
        pending.remoteStream = s;
        if (session) { session.remoteStream = s; attachMediaToFaces(); }
      },
      onClose: reason => leave(reason),
      onError: text => { if (session) leave(text); else { go('scr-online'); toast(text, 'foul'); } room = null; },
    });
    return room;
  }

  $('#btn-create').onclick = async () => {
    Sfx.resume(); await lobbyMedia(true);
    const r = newRoom(); pending.target = segValue('#seg-online-len');
    go('scr-wait'); $('#wait-code').textContent = '······'; $('#wait-note').textContent = 'Creating room…';
    try {
      const code = await r.host();
      $('#wait-code').textContent = code; $('#wait-note').textContent = 'Waiting for your friend to join…';
    } catch (e) { go('scr-online'); toast(e.message || 'Could not create room', 'foul'); }
  };
  $('#btn-share').onclick = async () => {
    const code = $('#wait-code').textContent, text = `Play Carrom with me on Carrom Champions! Room code: ${code}`;
    if (navigator.share) { try { await navigator.share({ title: 'Carrom Champions', text }); } catch (e) { } }
    else if (navigator.clipboard) { navigator.clipboard.writeText(code).then(() => toast('Code copied'), () => { }); }
  };
  $('#btn-wait-cancel').onclick = () => { if (room) room.destroy(); room = null; go('scr-online'); };
  $('#btn-join').onclick = async () => {
    const code = $('#in-code').value.trim().toUpperCase();
    if (code.length !== 6) return toast('Enter the 6-letter room code', 'warn');
    Sfx.resume(); await lobbyMedia(true);
    const r = newRoom(); go('scr-wait'); $('#wait-code').textContent = code; $('#wait-note').textContent = 'Joining room…';
    try { await r.join(code); } catch (e) { go('scr-online'); toast(e.message || 'Could not join', 'foul'); }
  };
  $('#in-code').oninput = e => { e.target.value = e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, ''); };

  // ---------- Local & practice ----------
  $('#in-p1').value = store.get('p1', ''); $('#in-p2').value = store.get('p2', '');
  $('#btn-start-local').onclick = async () => {
    Sfx.resume();
    const p1 = $('#in-p1').value.trim() || 'Player 1', p2 = $('#in-p2').value.trim() || 'Player 2';
    store.set('p1', $('#in-p1').value.trim()); store.set('p2', $('#in-p2').value.trim());
    await Media.start();
    startSession({ mode: 'local', names: [p1, p2], target: segValue('#seg-local-len'), flip: $('#chk-flip').checked });
  };
  $('#btn-practice').onclick = async () => { Sfx.resume(); await Media.start(); startSession({ mode: 'practice', names: [myName(), ''], target: 1 }); };

  // ---------- Layout ----------
  function layout() {
    const scr = $('#scr-game'); if (!scr.classList.contains('active')) return;
    const wrap = $('#board-wrap');
    const others = ['#hud-top', '#hud-bot', '.slider-row', '#hint', '.controls'].reduce((s, sel) => s + ($(sel).offsetHeight || 0), 0);
    const availH = scr.clientHeight - others - 6 * 6 - 52 - 16; // gaps + face overhang + padding
    const availW = scr.clientWidth - 20;
    const size = Math.max(240, Math.min(availW, availH, 640));
    wrap.style.width = size + 'px';
    if (game) game.resize();
  }
  window.addEventListener('resize', layout);

  // ---------- Android back button ----------
  window.onAndroidBack = function () {
    if ($('.modal.show')) { if (!(game && game.S.over)) closeModals(); return true; }
    if (current === 'scr-game') { openModal('mdl-menu'); return true; }
    if (current === 'scr-wait') { $('#btn-wait-cancel').click(); return true; }
    if (current !== 'scr-home') { go('scr-home'); return true; }
    return false;
  };

  function esc(s) { return String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }
  document.addEventListener('visibilitychange', () => { if (!document.hidden) Sfx.resume(); });
})();
