/* Carrom Champions — engine: board rendering, physics, rules, touch input.
 * No bots, no assists: only what a real player sees at a real board. */
(function (global) {
  'use strict';

  // ---------- Board geometry (1 unit ≈ 0.74 mm; playing surface 74 cm) ----------
  const W = 1000, FRAME = 80, VIEW = W + FRAME * 2;
  const COIN_R = 21.5, STRIKER_R = 28;
  const POCKET_R = 33, POCKET_IN = 36;
  const BASE_OUT = 137, BASE_GAP = COIN_R * 2;
  const BASE_X0 = 200, BASE_X1 = 800;
  const BASE_Y = [W - BASE_OUT - BASE_GAP / 2, BASE_OUT + BASE_GAP / 2]; // seat 0 bottom, seat 1 top
  const POCKETS = [[POCKET_IN, POCKET_IN], [W - POCKET_IN, POCKET_IN], [POCKET_IN, W - POCKET_IN], [W - POCKET_IN, W - POCKET_IN]];

  // ---------- Physics tuning ----------
  const MAX_SPEED = 4600;      // full-power flick
  const FRICTION = 1000;       // sliding friction on a powdered board
  const DAMP = 0.4;            // speed-proportional loss
  const STOP = 5;
  const E_PIECE = 0.93, E_WALL = 0.68, WALL_TANGENT = 0.92;
  const DT = 1 / 600;
  const MASS = { w: 5.5, b: 5.5, q: 5.5, s: 15 };
  const AIM_PULL = 230;        // pull distance for full power

  // ---------- Utilities ----------
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const hyp = Math.hypot;
  function rng(seed) { return function () { seed |= 0; seed = seed + 0x6D2B79F5 | 0; let t = Math.imul(seed ^ seed >>> 15, 1 | seed); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }

  // ---------- Sound (synthesised, no assets) ----------
  const Sfx = {
    ctx: null, on: true, last: 0,
    init() { if (this.ctx) return; try { this.ctx = new (window.AudioContext || window.webkitAudioContext)(); } catch (e) { this.ctx = null; } },
    resume() { this.init(); if (this.ctx && this.ctx.state === 'suspended') this.ctx.resume(); },
    tone(freq, dur, vol, type, decay) {
      if (!this.on || !this.ctx) return;
      const c = this.ctx, t = c.currentTime, o = c.createOscillator(), g = c.createGain();
      o.type = type || 'triangle'; o.frequency.setValueAtTime(freq, t);
      if (decay) o.frequency.exponentialRampToValueAtTime(freq * decay, t + dur);
      g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
      o.connect(g).connect(c.destination); o.start(t); o.stop(t + dur + 0.02);
    },
    noise(dur, vol, hp) {
      if (!this.on || !this.ctx) return;
      const c = this.ctx, n = Math.floor(c.sampleRate * dur), b = c.createBuffer(1, n, c.sampleRate), d = b.getChannelData(0);
      for (let i = 0; i < n; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / n, 3);
      const s = c.createBufferSource(), f = c.createBiquadFilter(), g = c.createGain();
      f.type = 'bandpass'; f.frequency.value = hp || 2200; f.Q.value = 1.2; g.gain.value = vol;
      s.buffer = b; s.connect(f).connect(g).connect(c.destination); s.start();
    },
    clack(i) { const now = performance.now(); if (now - this.last < 18) return; this.last = now; const v = clamp(i, 0.04, 1); this.noise(0.05, 0.55 * v, 2600 + Math.random() * 900); this.tone(1700 + Math.random() * 300, 0.04, 0.08 * v, 'sine'); },
    cushion(i) { const v = clamp(i, 0.05, 1); this.noise(0.09, 0.4 * v, 420); this.tone(110, 0.12, 0.25 * v, 'sine', 0.6); },
    pocket() { this.tone(240, 0.22, 0.35, 'sine', 0.45); this.noise(0.15, 0.25, 600); },
    flick(p) { this.noise(0.06, 0.4 + 0.5 * p, 1800); },
    foul() { this.tone(180, 0.35, 0.25, 'sawtooth', 0.7); },
    win() { [523, 659, 784, 1046].forEach((f, i) => setTimeout(() => this.tone(f, 0.3, 0.2, 'triangle'), i * 120)); },
  };

  // ---------- Initial layout ----------
  function layoutPieces(seat0White) {
    const pcs = []; let id = 0;
    const cx = W / 2, cy = W / 2, d = COIN_R * 2.03;
    pcs.push({ id: id++, k: 'q', x: cx, y: cy });
    for (let i = 0; i < 6; i++) { const a = i * Math.PI / 3 + Math.PI / 2; pcs.push({ id: id++, k: i % 2 ? 'b' : 'w', x: cx + Math.cos(a) * d, y: cy + Math.sin(a) * d }); }
    const outer = [];
    for (let i = 0; i < 6; i++) { const a = i * Math.PI / 3 + Math.PI / 2; outer.push({ a, r: 2 * d }); outer.push({ a: a + Math.PI / 6, r: Math.sqrt(3) * d }); }
    outer.sort((p, q) => p.a - q.a).forEach((o, i) => pcs.push({ id: id++, k: i % 2 ? 'w' : 'b', x: cx + Math.cos(o.a) * o.r, y: cy + Math.sin(o.a) * o.r }));
    // Striker
    pcs.push({ id: id++, k: 's', x: W / 2, y: BASE_Y[0] });
    pcs.forEach(p => { p.vx = 0; p.vy = 0; p.on = true; p.r = p.k === 's' ? STRIKER_R : COIN_R; p.m = MASS[p.k]; });
    return pcs;
  }

  // ---------- Rules (ICF-style, simplified where noted) ----------
  function newBoard(breaker, practice) {
    return {
      pieces: layoutPieces(), turn: breaker, breaker,
      colors: breaker === 0 ? ['w', 'b'] : ['b', 'w'],
      queen: { st: 'board', by: -1 }, lastX: [W / 2, W / 2], practice: !!practice, over: false, winner: -1, shots: 0,
    };
  }
  const QUEEN_ID = 0, STRIKER_ID = 19;

  function countOn(S, k) { let n = 0; for (const p of S.pieces) if (p.k === k && p.on) n++; return n; }

  function placeAtCenter(S, p) {
    const ok = (x, y) => S.pieces.every(o => o === p || !o.on || o.k === 's' || hyp(o.x - x, o.y - y) >= o.r + p.r + 0.5);
    for (let r = 0; r < 260; r += 6) {
      const steps = r === 0 ? 1 : Math.ceil(2 * Math.PI * r / 14);
      for (let i = 0; i < steps; i++) {
        const a = i / steps * 2 * Math.PI, x = W / 2 + Math.cos(a) * r, y = W / 2 + Math.sin(a) * r;
        if (ok(x, y)) { p.x = x; p.y = y; p.vx = p.vy = 0; p.on = true; p.fall = null; return; }
      }
    }
    p.x = W / 2; p.y = W / 2; p.on = true; p.fall = null;
  }

  // Returns { events:[{text,kind}], cont, boardOver, winner }
  function resolveShot(S, seat, pottedIds, strikerIn) {
    const P = id => S.pieces[id];
    const me = S.colors[seat], op = S.colors[1 - seat];
    const ev = [];
    const own = pottedIds.filter(id => P(id).k === me);
    const opp = pottedIds.filter(id => P(id).k === op);
    const q = pottedIds.includes(QUEEN_ID);
    let cont = false;

    if (S.practice) {
      if (strikerIn) { ev.push({ text: 'Striker pocketed — foul', kind: 'foul' }); pottedIds.forEach(id => placeAtCenter(S, P(id))); }
      else if (pottedIds.length) ev.push({ text: pottedIds.length > 1 ? `${pottedIds.length} coins pocketed!` : 'Nice pot!', kind: 'good' });
      const left = S.pieces.filter(p => p.k !== 's' && p.on).length;
      if (left === 0) { S.over = true; S.winner = 0; return { events: [{ text: `Board cleared in ${S.shots} shots!`, kind: 'win' }], cont: true, boardOver: true, winner: 0 }; }
      return { events: ev, cont: true, boardOver: false, winner: -1 };
    }

    if (strikerIn) {
      ev.push({ text: 'Foul! Striker pocketed', kind: 'foul' });
      own.forEach(id => placeAtCenter(S, P(id)));
      if (q) placeAtCenter(S, P(QUEEN_ID));
      if (S.queen.st === 'pending' && S.queen.by === seat) { placeAtCenter(S, P(QUEEN_ID)); S.queen = { st: 'board', by: -1 }; }
      else if (q) S.queen = { st: 'board', by: -1 };
      const prev = S.pieces.find(p => p.k === me && !p.on && !own.includes(p.id));
      if (prev) { placeAtCenter(S, prev); ev.push({ text: 'Penalty: one coin returned', kind: 'foul' }); }
    } else {
      if (S.queen.st === 'pending' && S.queen.by === seat) {
        if (own.length) { S.queen = { st: 'covered', by: seat }; ev.push({ text: 'Queen covered! 👑', kind: 'win' }); }
        else { placeAtCenter(S, P(QUEEN_ID)); S.queen = { st: 'board', by: -1 }; ev.push({ text: 'Queen not covered — back to centre', kind: 'foul' }); }
      }
      if (q) {
        if (own.length) { S.queen = { st: 'covered', by: seat }; ev.push({ text: 'Queen pocketed & covered! 👑', kind: 'win' }); }
        else { S.queen = { st: 'pending', by: seat }; ev.push({ text: 'Queen pocketed — cover it now!', kind: 'good' }); }
      }
      if (own.length && !q) ev.push({ text: own.length > 1 ? `${own.length} coins!` : 'Good pot', kind: 'good' });
      if (opp.length) ev.push({ text: 'Opponent coin pocketed', kind: 'warn' });
      cont = own.length > 0 || q;
    }

    // The queen must be covered before either side's last coin goes down.
    if (S.queen.st !== 'covered') {
      for (const col of [me, op]) {
        if (countOn(S, col) === 0) {
          pottedIds.filter(id => P(id).k === col).forEach(id => placeAtCenter(S, P(id)));
          ev.push({ text: 'Queen must be covered before the last coin', kind: 'foul' });
          if (col === me) cont = false;
        }
      }
    }

    let winner = -1;
    if (S.queen.st === 'covered') {
      if (countOn(S, me) === 0) winner = seat;
      else if (countOn(S, op) === 0) winner = 1 - seat;
    }
    if (winner >= 0) { S.over = true; S.winner = winner; return { events: ev, cont: false, boardOver: true, winner }; }
    return { events: ev, cont, boardOver: false, winner: -1 };
  }

  function boardPoints(S, matchPoints) {
    const w = S.winner, loserColor = S.colors[1 - w];
    let pts = countOn(S, loserColor);
    const queenBonus = S.queen.by === w && matchPoints[w] < 22 ? 3 : 0;
    return { pts: Math.max(1, pts + queenBonus), queenBonus };
  }

  // ---------- Physics ----------
  function stepPhysics(S, dt, hooks) {
    const ps = S.pieces;
    for (const p of ps) {
      if (!p.on) continue;
      let s = hyp(p.vx, p.vy);
      if (s > 0) {
        const ns = Math.max(0, s - FRICTION * dt - DAMP * s * dt);
        if (ns < STOP) { p.vx = p.vy = 0; } else { p.vx *= ns / s; p.vy *= ns / s; }
        p.x += p.vx * dt; p.y += p.vy * dt;
      }
    }
    // Pockets
    for (const p of ps) {
      if (!p.on) continue;
      for (const [px, py] of POCKETS) {
        if (hyp(p.x - px, p.y - py) < POCKET_R) {
          p.on = false; p.fall = { x: p.x, y: p.y, px, py, t: 0 }; p.vx = p.vy = 0;
          hooks.potted(p); break;
        }
      }
    }
    // Cushions
    for (const p of ps) {
      if (!p.on) continue;
      if (p.x < p.r) { p.x = p.r; if (p.vx < 0) { hooks.wall(-p.vx); p.vx = -p.vx * E_WALL; p.vy *= WALL_TANGENT; } }
      else if (p.x > W - p.r) { p.x = W - p.r; if (p.vx > 0) { hooks.wall(p.vx); p.vx = -p.vx * E_WALL; p.vy *= WALL_TANGENT; } }
      if (p.y < p.r) { p.y = p.r; if (p.vy < 0) { hooks.wall(-p.vy); p.vy = -p.vy * E_WALL; p.vx *= WALL_TANGENT; } }
      else if (p.y > W - p.r) { p.y = W - p.r; if (p.vy > 0) { hooks.wall(p.vy); p.vy = -p.vy * E_WALL; p.vx *= WALL_TANGENT; } }
    }
    // Piece–piece
    for (let i = 0; i < ps.length; i++) {
      const a = ps[i]; if (!a.on) continue;
      for (let j = i + 1; j < ps.length; j++) {
        const b = ps[j]; if (!b.on) continue;
        const dx = b.x - a.x, dy = b.y - a.y, min = a.r + b.r, d2 = dx * dx + dy * dy;
        if (d2 >= min * min || d2 === 0) continue;
        const d = Math.sqrt(d2), nx = dx / d, ny = dy / d, over = min - d;
        const ia = 1 / a.m, ib = 1 / b.m, it = ia + ib;
        a.x -= nx * over * ia / it; a.y -= ny * over * ia / it;
        b.x += nx * over * ib / it; b.y += ny * over * ib / it;
        const vn = (b.vx - a.vx) * nx + (b.vy - a.vy) * ny;
        if (vn < 0) {
          const jimp = -(1 + E_PIECE) * vn / it;
          a.vx -= jimp * nx * ia; a.vy -= jimp * ny * ia;
          b.vx += jimp * nx * ib; b.vy += jimp * ny * ib;
          hooks.hit(-vn);
        }
      }
    }
  }
  const anyMoving = S => S.pieces.some(p => p.on && (p.vx || p.vy));

  // ---------- Rendering ----------
  function drawBoardTexture(size) {
    const cv = document.createElement('canvas'); cv.width = cv.height = size;
    const g = cv.getContext('2d'); const s = size / VIEW; g.scale(s, s);
    const R = rng(7);
    // Frame: deep polished rosewood
    const fr = g.createLinearGradient(0, 0, VIEW, VIEW);
    fr.addColorStop(0, '#5a2a14'); fr.addColorStop(0.5, '#7a3a1c'); fr.addColorStop(1, '#4a2010');
    roundRect(g, 0, 0, VIEW, VIEW, 34); g.fillStyle = fr; g.fill();
    g.save(); roundRect(g, 0, 0, VIEW, VIEW, 34); g.clip();
    for (let i = 0; i < 140; i++) { g.strokeStyle = `rgba(${R() < .5 ? '30,10,0' : '150,80,40'},${0.06 + R() * 0.08})`; g.lineWidth = 1 + R() * 3; g.beginPath(); const y = R() * VIEW; g.moveTo(0, y); g.bezierCurveTo(VIEW * .3, y + (R() - .5) * 40, VIEW * .7, y + (R() - .5) * 40, VIEW, y + (R() - .5) * 30); g.stroke(); }
    g.restore();
    // Gloss & bevel
    const gl = g.createLinearGradient(0, 0, 0, VIEW); gl.addColorStop(0, 'rgba(255,220,180,.25)'); gl.addColorStop(.15, 'rgba(255,255,255,0)'); gl.addColorStop(1, 'rgba(0,0,0,.25)');
    roundRect(g, 0, 0, VIEW, VIEW, 34); g.fillStyle = gl; g.fill();
    g.strokeStyle = 'rgba(255,210,160,.35)'; g.lineWidth = 3; roundRect(g, 6, 6, VIEW - 12, VIEW - 12, 30); g.stroke();
    // Inner shadow lip
    g.fillStyle = '#2a1206'; g.fillRect(FRAME - 8, FRAME - 8, W + 16, W + 16);

    g.translate(FRAME, FRAME);
    // Playing surface: light birch with grain
    const sf = g.createRadialGradient(W / 2, W / 2, 80, W / 2, W / 2, W * .75);
    sf.addColorStop(0, '#f6dfb1'); sf.addColorStop(1, '#e2bf85');
    g.fillStyle = sf; g.fillRect(0, 0, W, W);
    g.save(); g.beginPath(); g.rect(0, 0, W, W); g.clip();
    for (let i = 0; i < 220; i++) { g.strokeStyle = `rgba(150,95,40,${0.03 + R() * 0.06})`; g.lineWidth = .6 + R() * 1.8; g.beginPath(); const x = R() * W; g.moveTo(x, 0); g.bezierCurveTo(x + (R() - .5) * 30, W * .35, x + (R() - .5) * 30, W * .65, x + (R() - .5) * 25, W); g.stroke(); }
    g.restore();
    // Inner shadow along cushions
    for (const [x0, y0, x1, y1] of [[0, 0, 0, 30], [0, W, 0, W - 30]]) { const sh = g.createLinearGradient(x0, y0, x1, y1); sh.addColorStop(0, 'rgba(60,25,5,.35)'); sh.addColorStop(1, 'rgba(60,25,5,0)'); g.fillStyle = sh; g.fillRect(0, Math.min(y0, y1), W, 30); }
    for (const [x0, x1] of [[0, 30], [W, W - 30]]) { const sh = g.createLinearGradient(x0, 0, x1, 0); sh.addColorStop(0, 'rgba(60,25,5,.35)'); sh.addColorStop(1, 'rgba(60,25,5,0)'); g.fillStyle = sh; g.fillRect(Math.min(x0, x1), 0, 30, W); }

    const INK = '#1b0f08', RED = '#b3161c';
    // Baselines on all four sides
    for (let side = 0; side < 4; side++) {
      g.save(); g.translate(W / 2, W / 2); g.rotate(side * Math.PI / 2); g.translate(-W / 2, -W / 2);
      const yOut = W - BASE_OUT, yIn = yOut - BASE_GAP, yMid = (yOut + yIn) / 2;
      g.strokeStyle = INK; g.lineWidth = 2.6;
      g.beginPath(); g.moveTo(BASE_X0, yOut); g.lineTo(BASE_X1, yOut); g.moveTo(BASE_X0, yIn); g.lineTo(BASE_X1, yIn); g.stroke();
      for (const x of [BASE_X0, BASE_X1]) {
        g.beginPath(); g.arc(x, yMid, COIN_R, 0, Math.PI * 2); g.fillStyle = RED; g.fill(); g.stroke();
        g.beginPath(); g.arc(x, yMid, COIN_R * .55, 0, Math.PI * 2); g.strokeStyle = 'rgba(255,230,200,.6)'; g.lineWidth = 1.2; g.stroke(); g.strokeStyle = INK; g.lineWidth = 2.6;
      }
      g.restore();
    }
    // Diagonal arrows toward pockets
    for (const [px, py] of POCKETS) {
      const dx = Math.sign(px - W / 2), dy = Math.sign(py - W / 2);
      const sx = W / 2 + dx * 160, sy = W / 2 + dy * 160, ex = px - dx * 62, ey = py - dy * 62;
      g.strokeStyle = INK; g.lineWidth = 2.6; g.beginPath(); g.moveTo(sx, sy); g.lineTo(ex, ey); g.stroke();
      // arrowhead
      const a = Math.atan2(ey - sy, ex - sx);
      g.beginPath(); g.moveTo(ex, ey); g.lineTo(ex - Math.cos(a - .35) * 26, ey - Math.sin(a - .35) * 26); g.moveTo(ex, ey); g.lineTo(ex - Math.cos(a + .35) * 26, ey - Math.sin(a + .35) * 26); g.stroke();
      // ornamental arc at inner end
      g.beginPath(); g.arc(sx + dx * 30, sy + dy * 30, 34, a + Math.PI * .6, a + Math.PI * 1.4); g.stroke();
    }
    // Centre rosette
    g.save(); g.translate(W / 2, W / 2);
    g.strokeStyle = INK; g.lineWidth = 3; g.beginPath(); g.arc(0, 0, 115, 0, Math.PI * 2); g.stroke();
    g.lineWidth = 1.6; g.beginPath(); g.arc(0, 0, 106, 0, Math.PI * 2); g.stroke();
    for (let i = 0; i < 8; i++) {
      g.save(); g.rotate(i * Math.PI / 4);
      g.beginPath(); g.moveTo(0, 0); g.quadraticCurveTo(26, -50, 0, -98); g.quadraticCurveTo(-26, -50, 0, 0);
      g.fillStyle = i % 2 ? INK : RED; g.globalAlpha = .9; g.fill(); g.globalAlpha = 1; g.restore();
    }
    g.beginPath(); g.arc(0, 0, COIN_R + 2, 0, Math.PI * 2); g.fillStyle = '#f3d9a8'; g.fill(); g.lineWidth = 2.5; g.stroke();
    g.beginPath(); g.arc(0, 0, COIN_R - 6, 0, Math.PI * 2); g.fillStyle = RED; g.fill();
    g.restore();
    // Pockets: netted holes
    for (const [px, py] of POCKETS) {
      const pg = g.createRadialGradient(px, py, 4, px, py, POCKET_R + 4);
      pg.addColorStop(0, '#000'); pg.addColorStop(.75, '#120804'); pg.addColorStop(1, '#3a1d0b');
      g.beginPath(); g.arc(px, py, POCKET_R + 4, 0, Math.PI * 2); g.fillStyle = pg; g.fill();
      g.strokeStyle = 'rgba(255,200,140,.25)'; g.lineWidth = 2; g.stroke();
      g.save(); g.clip(); g.strokeStyle = 'rgba(200,170,130,.12)'; g.lineWidth = 1;
      for (let k = -40; k <= 40; k += 8) { g.beginPath(); g.moveTo(px + k, py - 40); g.lineTo(px + k + 40, py + 40); g.moveTo(px + k, py - 40); g.lineTo(px + k - 40, py + 40); g.stroke(); }
      g.restore();
    }
    return cv;
  }

  function roundRect(g, x, y, w, h, r) { g.beginPath(); g.moveTo(x + r, y); g.arcTo(x + w, y, x + w, y + h, r); g.arcTo(x + w, y + h, x, y + h, r); g.arcTo(x, y + h, x, y, r); g.arcTo(x, y, x + w, y, r); g.closePath(); }

  function pieceSprite(kind, rPx, tint) {
    const pad = Math.ceil(rPx * .35), size = Math.ceil(rPx * 2 + pad * 2);
    const cv = document.createElement('canvas'); cv.width = cv.height = size;
    const g = cv.getContext('2d'), c = size / 2, r = rPx;
    const pal = {
      w: ['#fffaf0', '#efe2c8', '#b9a888', '#8a7a5e'],
      b: ['#4a4a4a', '#1f1f1f', '#0c0c0c', '#555'],
      q: ['#ff6a6a', '#d0161e', '#7d070c', '#ffb0a0'],
      s: tint ? ['#ffd9d9', '#e88', '#a33', '#fff'] : ['#ffffff', '#e8f0ff', '#9fb3d1', '#2b4c8c'],
    }[kind];
    const body = g.createRadialGradient(c - r * .35, c - r * .4, r * .1, c, c, r);
    body.addColorStop(0, pal[0]); body.addColorStop(.6, pal[1]); body.addColorStop(1, pal[2]);
    g.beginPath(); g.arc(c, c, r, 0, Math.PI * 2); g.fillStyle = body; g.fill();
    g.lineWidth = Math.max(1, r * .06); g.strokeStyle = 'rgba(0,0,0,.35)'; g.stroke();
    // Engraved rings
    g.lineWidth = Math.max(1, r * .05);
    g.strokeStyle = kind === 'b' ? 'rgba(255,255,255,.18)' : 'rgba(0,0,0,.18)';
    g.beginPath(); g.arc(c, c, r * .72, 0, Math.PI * 2); g.stroke();
    g.beginPath(); g.arc(c, c, r * .4, 0, Math.PI * 2); g.stroke();
    if (kind === 's') {
      g.strokeStyle = pal[3]; g.lineWidth = r * .1;
      g.beginPath(); g.arc(c, c, r * .58, 0, Math.PI * 2); g.stroke();
      for (let i = 0; i < 8; i++) { const a = i * Math.PI / 4; g.beginPath(); g.moveTo(c + Math.cos(a) * r * .2, c + Math.sin(a) * r * .2); g.lineTo(c + Math.cos(a) * r * .45, c + Math.sin(a) * r * .45); g.lineWidth = r * .06; g.stroke(); }
    }
    if (kind === 'q') { g.fillStyle = 'rgba(255,230,150,.9)'; g.font = `${r * .9}px serif`; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText('♛', c, c + r * .05); }
    // Specular
    const sp = g.createRadialGradient(c - r * .4, c - r * .45, 0, c - r * .4, c - r * .45, r * .6);
    sp.addColorStop(0, 'rgba(255,255,255,.55)'); sp.addColorStop(1, 'rgba(255,255,255,0)');
    g.beginPath(); g.arc(c, c, r, 0, Math.PI * 2); g.fillStyle = sp; g.fill();
    return cv;
  }

  // ---------- Game controller ----------
  class CarromGame {
    /**
     * opts: { canvas, mode:'online'|'local'|'practice', localSeat, matchTarget, flipLocal,
     *         onPlace(x), onAim(dx,dy,p), onShot(shot), onResolved(info), onToast(text,kind), onTurn(seat) }
     */
    constructor(opts) {
      this.o = opts; this.cv = opts.canvas; this.g = this.cv.getContext('2d');
      this.mode = opts.mode; this.localSeat = opts.localSeat || 0;
      this.match = { points: [0, 0], boardNo: 1, target: opts.matchTarget || 25, done: false };
      this.S = newBoard(0, this.mode === 'practice');
      this.phase = 'ready';           // ready | moving | waiting(remote state) | over
      this.drag = null; this.aim = null; this.remoteAim = null;
      this.potted = []; this.strikerIn = false; this.pendingState = null;
      this.acc = 0; this.lastT = 0; this.rot = 0; this.targetRot = 0;
      this.turnStart = performance.now(); this.turnLimit = 30000;
      this.resetStriker();
      this.updateRotation(true);
      this.resize();
      this._onResize = () => this.resize(); window.addEventListener('resize', this._onResize);
      this.bindInput();
      this.running = true; requestAnimationFrame(t => this.loop(t));
    }
    destroy() { this.running = false; window.removeEventListener('resize', this._onResize); this.unbind && this.unbind(); }

    get striker() { return this.S.pieces[STRIKER_ID]; }
    canControl() { return this.phase === 'ready' && !this.S.over && (this.mode !== 'online' || this.S.turn === this.localSeat); }
    viewSeat() { if (this.mode === 'online') return this.localSeat; if (this.mode === 'local' && this.o.flipLocal) return this.S.turn; return 0; }
    updateRotation(snap) { this.targetRot = this.viewSeat() === 1 ? Math.PI : 0; if (snap) this.rot = this.targetRot; }

    resetStriker() {
      const s = this.striker, t = this.S.turn;
      s.on = true; s.fall = null; s.vx = s.vy = 0; s.y = BASE_Y[t]; s.x = this.S.lastX[t];
      this.nudgeStrikerFree();
      this.turnStart = performance.now();
    }
    strikerValid(x) {
      const s = this.striker, y = BASE_Y[this.S.turn];
      return this.S.pieces.every(p => p === s || !p.on || hyp(p.x - x, p.y - y) >= p.r + s.r);
    }
    nudgeStrikerFree() {
      const s = this.striker; if (this.strikerValid(s.x)) return;
      for (let d = 4; d < 700; d += 4) for (const x of [s.x + d, s.x - d]) if (x >= BASE_X0 && x <= BASE_X1 && this.strikerValid(x)) { s.x = x; return; }
    }
    setStrikerX(x) { if (this.phase !== 'ready') return; this.striker.x = clamp(x, BASE_X0, BASE_X1); this.S.lastX[this.S.turn] = this.striker.x; }

    // --- Sizing ---
    resize() {
      const rect = this.cv.getBoundingClientRect(); const dpr = Math.min(window.devicePixelRatio || 1, 2.5);
      const px = Math.max(200, Math.round(rect.width * dpr));
      if (px === this.px) return;
      this.px = px; this.cv.width = this.cv.height = px; this.scale = px / VIEW;
      this.boardTex = drawBoardTexture(px);
      this.sprites = {}; for (const k of ['w', 'b', 'q', 's']) this.sprites[k] = pieceSprite(k, (k === 's' ? STRIKER_R : COIN_R) * this.scale);
      this.sprites.sBad = pieceSprite('s', STRIKER_R * this.scale, true);
    }

    // --- Input ---
    toPlay(ev) {
      const r = this.cv.getBoundingClientRect();
      let x = (ev.clientX - r.left) / r.width * VIEW, y = (ev.clientY - r.top) / r.height * VIEW;
      if (this.viewSeat() === 1) { x = VIEW - x; y = VIEW - y; }
      return { x: x - FRAME, y: y - FRAME };
    }
    bindInput() {
      const cv = this.cv;
      const down = e => {
        Sfx.resume(); if (!this.canControl()) return;
        const p = this.toPlay(e), s = this.striker;
        cv.setPointerCapture && cv.setPointerCapture(e.pointerId);
        if (hyp(p.x - s.x, p.y - s.y) < STRIKER_R * 2.3) { this.drag = { type: 'aim', id: e.pointerId }; this.aim = { dx: 0, dy: 0, p: 0 }; }
        else if (Math.abs(p.y - s.y) < 85) { this.drag = { type: 'place', id: e.pointerId }; this.setStrikerX(p.x); this.o.onPlace && this.o.onPlace(this.striker.x); }
        e.preventDefault();
      };
      const move = e => {
        if (!this.drag || this.drag.id !== e.pointerId) return;
        const p = this.toPlay(e), s = this.striker;
        if (this.drag.type === 'place') { this.setStrikerX(p.x); this.o.onPlace && this.o.onPlace(this.striker.x); }
        else {
          const dx = s.x - p.x, dy = s.y - p.y, len = hyp(dx, dy);
          const pw = clamp((len - 12) / AIM_PULL, 0, 1);
          this.aim = len > 0.01 ? { dx: dx / len, dy: dy / len, p: pw } : { dx: 0, dy: 0, p: 0 };
          this.o.onAim && this.o.onAim(this.aim);
        }
        e.preventDefault();
      };
      const up = e => {
        if (!this.drag || this.drag.id !== e.pointerId) return;
        const t = this.drag.type; this.drag = null;
        if (t === 'aim') {
          const a = this.aim; this.aim = null;
          if (a && a.p > 0.05 && this.strikerValid(this.striker.x)) this.shootLocal(a);
          else { this.o.onAim && this.o.onAim(null); if (a && a.p > 0.05) this.o.onToast && this.o.onToast('Striker is touching a coin — slide it clear', 'warn'); }
        }
      };
      cv.addEventListener('pointerdown', down); cv.addEventListener('pointermove', move);
      cv.addEventListener('pointerup', up); cv.addEventListener('pointercancel', up);
      this.unbind = () => { cv.removeEventListener('pointerdown', down); cv.removeEventListener('pointermove', move); cv.removeEventListener('pointerup', up); cv.removeEventListener('pointercancel', up); };
    }

    // --- Shots ---
    shootLocal(a) {
      const v = a.p * a.p * 0.35 + a.p * 0.65; // gentle curve: fine control at low power
      const shot = { seat: this.S.turn, x: this.striker.x, vx: a.dx * v * MAX_SPEED, vy: a.dy * v * MAX_SPEED, p: a.p };
      this.launch(shot, true);
      this.o.onShot && this.o.onShot(shot);
    }
    applyRemoteShot(shot) { if (this.phase !== 'ready') return; this.launch(shot, false); }
    launch(shot, authoritative) {
      const sp = hyp(shot.vx, shot.vy);
      if (!isFinite(sp) || sp > MAX_SPEED * 1.01) return; // reject tampered shots
      const s = this.striker; s.x = clamp(shot.x, BASE_X0, BASE_X1); s.y = BASE_Y[this.S.turn]; s.vx = shot.vx; s.vy = shot.vy;
      this.S.lastX[this.S.turn] = s.x;
      this.authoritative = authoritative; this.potted = []; this.strikerIn = false; this.remoteAim = null;
      this.phase = 'moving'; this.S.shots++; Sfx.flick(shot.p || .5);
    }

    // --- Remote state sync (shooter's device is authoritative for its own shot) ---
    snapshot() {
      return { pieces: this.S.pieces.map(p => [p.id, Math.round(p.x * 100) / 100, Math.round(p.y * 100) / 100, p.on ? 1 : 0]), turn: this.S.turn, colors: this.S.colors, queen: this.S.queen, lastX: this.S.lastX, over: this.S.over, winner: this.S.winner, breaker: this.S.breaker, shots: this.S.shots, match: this.match };
    }
    applyState(st, info) {
      if (this.phase === 'moving') { this.pendingState = { st, info }; return; }
      for (const [id, x, y, on] of st.pieces) { const p = this.S.pieces[id]; p.x = x; p.y = y; p.vx = p.vy = 0; if (on && !p.on) p.fall = null; p.on = !!on; }
      Object.assign(this.S, { turn: st.turn, colors: st.colors, queen: st.queen, lastX: st.lastX, over: st.over, winner: st.winner, breaker: st.breaker, shots: st.shots });
      this.match = st.match;
      this.phase = this.S.over ? 'over' : 'ready';
      if (!this.S.over) this.resetStriker();
      this.updateRotation();
      if (info) this.finishTurnUI(info, false);
    }

    settle() {
      const S = this.S, seat = S.turn;
      if (this.mode === 'online' && !this.authoritative) {
        this.phase = 'waiting';
        if (this.pendingState) { const ps = this.pendingState; this.pendingState = null; this.phase = 'ready'; this.applyState(ps.st, ps.info); }
        return;
      }
      const ids = this.potted.filter(id => id !== STRIKER_ID);
      const res = resolveShot(S, seat, ids, this.strikerIn);
      let info = { events: res.events, boardOver: res.boardOver, winner: res.winner, seat };
      if (res.boardOver && !S.practice) {
        const bp = boardPoints(S, this.match.points);
        this.match.points[res.winner] += bp.pts;
        info.boardPts = bp.pts; info.queenBonus = bp.queenBonus;
        if (this.match.points[res.winner] >= this.match.target || this.match.boardNo >= 8) this.match.done = true;
        info.matchDone = this.match.done;
      }
      if (!res.boardOver && !res.cont && !S.practice) S.turn = 1 - S.turn;
      this.phase = S.over ? 'over' : 'ready';
      if (!S.over) this.resetStriker();
      this.updateRotation();
      this.finishTurnUI(info, true);
    }
    finishTurnUI(info, local) {
      for (const e of info.events) { this.o.onToast && this.o.onToast(e.text, e.kind); if (e.kind === 'foul') Sfx.foul(); }
      if (info.boardOver) Sfx.win();
      this.o.onResolved && this.o.onResolved(info, local);
    }
    timeoutTurn() {
      if (!this.canControl() || this.S.practice) return;
      this.S.turn = 1 - this.S.turn; this.resetStriker(); this.updateRotation();
      const info = { events: [{ text: 'Time up — turn passes', kind: 'warn' }], boardOver: false, winner: -1, seat: 1 - this.S.turn };
      this.finishTurnUI(info, true);
    }
    nextBoard() {
      const breaker = 1 - this.S.breaker;
      this.S = newBoard(breaker, this.mode === 'practice'); this.match.boardNo++;
      this.phase = 'ready'; this.resetStriker(); this.updateRotation();
    }
    restartMatch() { this.match = { points: [0, 0], boardNo: 1, target: this.match.target, done: false }; this.S = newBoard(0, this.mode === 'practice'); this.phase = 'ready'; this.resetStriker(); this.updateRotation(); }

    // --- Main loop ---
    loop(t) {
      if (!this.running) return;
      const dt = Math.min(0.05, (t - (this.lastT || t)) / 1000); this.lastT = t;
      if (this.phase === 'moving') {
        this.acc += dt;
        const hooks = {
          hit: v => Sfx.clack(v / 2200), wall: v => Sfx.cushion(v / 2600),
          potted: p => { this.potted.push(p.id); if (p.id === STRIKER_ID) this.strikerIn = true; Sfx.pocket(); if (navigator.vibrate && this.o.vibrate !== false) navigator.vibrate(25); },
        };
        while (this.acc >= DT) { stepPhysics(this.S, DT, hooks); this.acc -= DT; }
        if (!anyMoving(this.S)) { this.acc = 0; this.settle(); }
      }
      for (const p of this.S.pieces) if (p.fall) { p.fall.t += dt; }
      // Smooth board rotation for pass & play
      const dr = this.targetRot - this.rot; this.rot += Math.abs(dr) < 0.01 ? dr : dr * Math.min(1, dt * 7);
      // Turn clock
      if (this.phase === 'ready' && this.mode !== 'practice' && this.canControl() && performance.now() - this.turnStart > this.turnLimit) this.timeoutTurn();
      this.render();
      requestAnimationFrame(tt => this.loop(tt));
    }
    turnProgress() { return this.phase === 'ready' && this.mode !== 'practice' ? clamp((performance.now() - this.turnStart) / this.turnLimit, 0, 1) : 0; }

    render() {
      const g = this.g, s = this.scale, px = this.px;
      g.setTransform(1, 0, 0, 1, 0, 0); g.clearRect(0, 0, px, px);
      g.translate(px / 2, px / 2); g.rotate(this.rot); g.translate(-px / 2, -px / 2);
      g.drawImage(this.boardTex, 0, 0);
      g.translate(FRAME * s, FRAME * s);
      // Highlight active baseline
      if (this.phase === 'ready' && !this.S.over) {
        const y = BASE_Y[this.S.turn] * s, mine = this.canControl();
        g.fillStyle = mine ? 'rgba(255,215,90,.18)' : 'rgba(255,255,255,.08)';
        g.fillRect(BASE_X0 * s, y - COIN_R * s, (BASE_X1 - BASE_X0) * s, COIN_R * 2 * s);
      }
      // Shadows
      g.fillStyle = 'rgba(40,20,5,.28)';
      for (const p of this.S.pieces) if (p.on) { g.beginPath(); g.ellipse((p.x + 3) * s, (p.y + 5) * s, p.r * s, p.r * s * .92, 0, 0, Math.PI * 2); g.fill(); }
      // Falling pieces
      for (const p of this.S.pieces) {
        if (!p.on && p.fall && p.fall.t < 0.35) {
          const k = p.fall.t / 0.35, x = p.fall.x + (p.fall.px - p.fall.x) * k, y = p.fall.y + (p.fall.py - p.fall.y) * k;
          const spr = this.sprites[p.k], sc = 1 - k * .55; g.globalAlpha = 1 - k * .8;
          g.drawImage(spr, x * s - spr.width * sc / 2, y * s - spr.height * sc / 2, spr.width * sc, spr.height * sc); g.globalAlpha = 1;
        }
      }
      const st = this.striker, valid = this.phase !== 'ready' || this.strikerValid(st.x);
      for (const p of this.S.pieces) {
        if (!p.on) continue;
        const spr = p.k === 's' && !valid ? this.sprites.sBad : this.sprites[p.k];
        g.save(); g.translate(p.x * s, p.y * s);
        if (this.viewSeat() === 1) g.rotate(Math.PI); // keep queen crown upright for the viewer
        g.drawImage(spr, -spr.width / 2, -spr.height / 2); g.restore();
      }
      // Aim indicator — direction + power only, no trajectory prediction
      const a = this.aim || (this.mode === 'online' && this.S.turn !== this.localSeat ? this.remoteAim : null);
      if (a && a.p > 0 && this.phase === 'ready') {
        const mine = !!this.aim, len = (60 + a.p * 170) * s, x0 = st.x * s, y0 = st.y * s;
        const col = `hsl(${120 - a.p * 120},90%,${mine ? 50 : 70}%)`;
        g.globalAlpha = mine ? 1 : .55;
        g.strokeStyle = col; g.lineWidth = 4 * s * 1.6; g.lineCap = 'round'; g.setLineDash([10 * s, 9 * s]);
        g.beginPath(); g.moveTo(x0 + a.dx * STRIKER_R * s * 1.2, y0 + a.dy * STRIKER_R * s * 1.2); g.lineTo(x0 + a.dx * len, y0 + a.dy * len); g.stroke(); g.setLineDash([]);
        const ex = x0 + a.dx * len, ey = y0 + a.dy * len, an = Math.atan2(a.dy, a.dx);
        g.fillStyle = col; g.beginPath(); g.moveTo(ex + Math.cos(an) * 16 * s, ey + Math.sin(an) * 16 * s); g.lineTo(ex + Math.cos(an + 2.5) * 16 * s, ey + Math.sin(an + 2.5) * 16 * s); g.lineTo(ex + Math.cos(an - 2.5) * 16 * s, ey + Math.sin(an - 2.5) * 16 * s); g.fill();
        // power ring
        g.lineWidth = 5 * s; g.strokeStyle = col; g.beginPath(); g.arc(x0, y0, (STRIKER_R + 9) * s, -Math.PI / 2, -Math.PI / 2 + a.p * Math.PI * 2); g.stroke();
        g.globalAlpha = 1;
      } else if (this.canControl() && !this.drag) {
        // gentle pulse to invite the touch
        const k = (Math.sin(performance.now() / 300) + 1) / 2;
        g.strokeStyle = `rgba(255,215,90,${.35 + k * .4})`; g.lineWidth = 3 * s;
        g.beginPath(); g.arc(st.x * s, st.y * s, (STRIKER_R + 6 + k * 5) * s, 0, Math.PI * 2); g.stroke();
      }
    }
  }

  global.Carrom = { CarromGame, Sfx, resolveShot, newBoard, stepPhysics, anyMoving, layoutPieces, boardPoints, consts: { W, BASE_X0, BASE_X1, BASE_Y, STRIKER_ID, QUEEN_ID, MAX_SPEED } };
})(typeof window !== 'undefined' ? window : globalThis);
