/* Carrom Champions — online rooms, face camera and voice over WebRTC (PeerJS). */
(function (global) {
  'use strict';
  const PREFIX = 'carromchamp-v1-';
  const PEERJS_SRC = ['https://unpkg.com/peerjs@1.5.4/dist/peerjs.min.js', 'https://cdn.jsdelivr.net/npm/peerjs@1.5.4/dist/peerjs.min.js'];

  function loadScript(src) {
    return new Promise((res, rej) => { const s = document.createElement('script'); s.src = src; s.onload = res; s.onerror = rej; document.head.appendChild(s); });
  }
  async function ensurePeerJS() {
    if (global.Peer) return;
    for (const src of PEERJS_SRC) { try { await loadScript(src); if (global.Peer) return; } catch (e) { /* try next */ } }
    throw new Error('Could not reach the online service. Check your internet connection.');
  }
  function makeCode() { const a = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789'; let s = ''; const r = crypto.getRandomValues(new Uint8Array(6)); for (const b of r) s += a[b % a.length]; return s; }

  const Media = {
    stream: null,
    async start() {
      if (this.stream) return this.stream;
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) return null;
      try {
        this.stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: 'user', width: { ideal: 320 }, height: { ideal: 320 }, frameRate: { ideal: 20, max: 24 } },
          audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true },
        });
      } catch (e) {
        try { this.stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true } }); } catch (e2) { this.stream = null; }
      }
      return this.stream;
    },
    setMic(on) { if (this.stream) this.stream.getAudioTracks().forEach(t => t.enabled = on); },
    setCam(on) { if (this.stream) this.stream.getVideoTracks().forEach(t => t.enabled = on); },
    hasVideo() { return !!(this.stream && this.stream.getVideoTracks().length); },
    hasAudio() { return !!(this.stream && this.stream.getAudioTracks().length); },
    stop() { if (this.stream) this.stream.getTracks().forEach(t => t.stop()); this.stream = null; },
    // A silent outgoing stream lets a player without camera/mic still receive the opponent's.
    silentStream() {
      try { const ctx = new (window.AudioContext || window.webkitAudioContext)(); const d = ctx.createMediaStreamDestination(); return d.stream; } catch (e) { return null; }
    },
  };

  class Room {
    /** handlers: { onOpen(code), onConnected(), onMessage(msg), onRemoteStream(stream), onClose(reason), onError(text) } */
    constructor(handlers) { this.h = handlers; this.peer = null; this.conn = null; this.call = null; this.closed = false; }

    async host() {
      await ensurePeerJS();
      const tryOpen = () => new Promise((res, rej) => {
        const code = makeCode(); const peer = new Peer(PREFIX + code, { debug: 0 });
        peer.on('open', () => res({ peer, code }));
        peer.on('error', err => { if (err.type === 'unavailable-id') { peer.destroy(); res(null); } else rej(err); });
      });
      let r = null; for (let i = 0; i < 4 && !r; i++) r = await tryOpen();
      if (!r) throw new Error('Could not create a room. Try again.');
      this.peer = r.peer; this.code = r.code; this.isHost = true;
      this.wirePeer();
      this.peer.on('connection', conn => {
        if (this.conn) { conn.on('open', () => { conn.send({ t: 'full' }); setTimeout(() => conn.close(), 300); }); return; }
        this.attachConn(conn);
      });
      this.peer.on('call', call => {
        this.call = call; call.answer(Media.stream || undefined);
        call.on('stream', s => this.h.onRemoteStream && this.h.onRemoteStream(s));
      });
      this.h.onOpen && this.h.onOpen(this.code);
      return this.code;
    }

    async join(code) {
      await ensurePeerJS();
      code = String(code || '').trim().toUpperCase();
      this.peer = await new Promise((res, rej) => { const p = new Peer({ debug: 0 }); p.on('open', () => res(p)); p.on('error', rej); });
      this.isHost = false; this.code = code;
      this.wirePeer();
      const conn = this.peer.connect(PREFIX + code, { reliable: true, serialization: 'json' });
      this.attachConn(conn);
      const timer = setTimeout(() => { if (!this.conn || !this.conn.open) this.fail('Room not found. Check the code.'); }, 12000);
      conn.on('open', () => {
        clearTimeout(timer);
        const out = Media.stream || Media.silentStream();
        if (out) {
          const call = this.peer.call(PREFIX + code, out); this.call = call;
          call.on('stream', s => this.h.onRemoteStream && this.h.onRemoteStream(s));
        }
      });
    }

    wirePeer() {
      this.peer.on('error', err => {
        if (err.type === 'peer-unavailable') this.fail('Room not found. Check the code.');
        else if (err.type === 'network' || err.type === 'server-error' || err.type === 'socket-error') this.fail('Connection problem. Check your internet.');
      });
      this.peer.on('disconnected', () => { if (!this.closed && this.peer && !this.peer.destroyed) try { this.peer.reconnect(); } catch (e) { } });
    }
    attachConn(conn) {
      this.conn = conn;
      conn.on('open', () => this.h.onConnected && this.h.onConnected());
      conn.on('data', d => { if (d && d.t === 'full') return this.fail('That room already has two players.'); this.h.onMessage && this.h.onMessage(d); });
      conn.on('close', () => { if (!this.closed) { this.closed = true; this.h.onClose && this.h.onClose('Opponent left the game'); } });
      conn.on('error', () => { });
    }
    send(msg) { if (this.conn && this.conn.open) this.conn.send(msg); }
    fail(text) { if (this.closed) return; this.closed = true; this.h.onError && this.h.onError(text); this.destroy(); }
    destroy() { this.closed = true; try { this.call && this.call.close(); } catch (e) { } try { this.conn && this.conn.close(); } catch (e) { } try { this.peer && this.peer.destroy(); } catch (e) { } this.peer = this.conn = this.call = null; }
  }

  global.CarromNet = { Room, Media, makeCode };
})(window);
