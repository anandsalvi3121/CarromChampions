# Carrom Champions 🏆

A championship-style carrom game for Android — real players only, face to face.

- **No bots, no aim assist, no cheat codes.** The aim arrow shows only direction and power, never a predicted path. Shots are physics-checked (tampered/over-power shots are rejected).
- **Live face circles on the board** — your front camera in your circle, your opponent's in theirs, with **voice chat** and a green glow when someone talks.
- **Realistic board & physics** — ICF proportions (74 cm board, coin/striker/pocket sizes), polished rosewood frame, powdered-board glide, cushion bounce, heavier striker.
- **Real rules** — break, continue on pot, Queen + cover, striker foul with penalty coin, Queen-before-last-coin, board points (+3 Queen under 22), matches to 25.
- **Modes:** Online (room code) · Pass & Play (board turns to face each player) · Practice.
- 30-second shot clock, quick reactions, sound + vibration, mic/camera/speaker toggles.

## Get the APK (no computer setup needed)

1. Create a free account at github.com and make a new **empty repository**.
2. Upload everything in this folder (keep the folder structure, including `.github`).
3. Open the **Actions** tab → **Build APK** runs automatically (≈5 minutes).
4. Open the finished run → download **CarromChampions-apk** → unzip → `CarromChampions.apk`.
5. Copy to your phone, tap it, allow "Install unknown apps" for your file manager.

On first open, Android asks for **Camera** and **Microphone** — tap Allow.

### Or build with Android Studio
Open the `android` folder → Build › Build APK(s).

## Playing online
One player taps **Play Online → Create room** and shares the 6-letter code; the other taps **Join**. Both phones need internet. Matchmaking uses the free PeerJS service; video and voice go directly phone-to-phone (WebRTC). On some strict mobile networks a direct connection can fail — Wi-Fi usually fixes it; for a public launch, add your own TURN server.

## Project layout
```
android/app/src/main/assets/www/   ← the game (HTML/CSS/JS)
  js/game.js   board rendering, physics, rules, touch controls
  js/net.js    rooms, camera/mic, WebRTC
  js/app.js    screens, HUD, face circles, online protocol
android/app/src/main/java/.../MainActivity.java   WebView host + permissions
.github/workflows/build-apk.yml                     cloud APK build
```

Before publishing to Google Play: change `applicationId`, sign with your own keystore, and add a privacy policy (camera & mic are used).
